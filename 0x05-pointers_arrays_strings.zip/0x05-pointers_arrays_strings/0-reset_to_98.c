#include <stdlib.h>
#include <stdio.h>
/**
 * reset_to_98 - a pointer to an int as parameter and updates the value it points to to 98.
 * @n: accept input  parameter c of type int
 * Return: 98.
 */
void reset_to_98(int *n)
{
	 *n = 98;
	 return;
}
